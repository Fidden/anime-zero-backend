<?php

namespace App\Jobs;

use App\Models\Film;
use App\Models\FilmGenre;
use App\Models\Genre;
use App\Models\Status;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Arr;

class FilmParseJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private string $token;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->token = 'ac8c072e62855540ec492698e2c1c326';
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('max_execution_time', 9999999999);

        $request = $this->request("https://kodikapi.com/list?token={$this->token}&types=anime-serial&with_material_data=true");

        while ($request['next_page']) {
            foreach ($request['results'] as $result) {
                if (!$this->isFilmValid($result))
                    continue;

                $film_status = Status::firstOrCreate([
                    'name' => $this->getProperty($result['material_data'], 'all_status', 1)
                ]);

                $film = Film::create([
                    'kodik_id' => $this->getProperty($result, 'id'),
                    'player_link' => $this->getProperty($result, 'link'),
                    'title' => $this->getProperty($result, 'title'),
                    'title_orig' => $this->getProperty($result, 'title_orig'),
                    'description' => $this->getProperty($result['material_data'], 'description'),
                    'year' => $this->getProperty($result, 'year'),
                    'poster' => $this->getProperty($result['material_data'], 'poster_url'),
                    'rating' => $this->getRating($result),
                    'minimal_age' => $this->getProperty($result['material_data'], 'minimal_age'),
                    'status_id' => $film_status->id,
                    'content_type_id' => 2,
                ]);

                if (!$this->getProperty($result['material_data'], 'anime_genres'))
                    continue;

                foreach ($result['material_data']['anime_genres'] as $genre) {
                    $genre = Genre::firstOrCreate([
                        'name' => $genre
                    ]);

                    FilmGenre::firstOrCreate([
                        'film_id' => $film->id,
                        'genre_id' => $genre->id,
                    ]);
                }
            }

            $request = $this->request($request['next_page']);
        }
    }

    public function request($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        return json_decode(curl_exec($ch), true);
    }

    public function isFilmValid(array $result): bool
    {
        if (!Arr::exists($result, 'title'))
            return false;

        if (!Arr::exists($result, 'material_data'))
            return false;

        if (!Arr::exists($result['material_data'], 'poster_url'))
            return false;

        if (Film::where('title', $result['title'])->exists() ||
            Film::where('title_orig', $result['title_orig'])->exists() ||
            Film::where('kodik_id', $result['id'])->exists())
            return false;

        return true;
    }

    public function getProperty(array $array, string $property, mixed $default = null)
    {
        return Arr::exists($array, $property) ? $array[$property] : $default;
    }

    public function getRating($result): int|float
    {
        if ($this->getProperty($result['material_data'], 'kinopoisk_rating'))
            return $result['material_data']['kinopoisk_rating'];
        else if ($this->getProperty($result['material_data'], 'imdb_rating'))
            return $result['material_data']['imdb_rating'];
        else if ($this->getProperty($result['material_data'], 'shikimori_rating'))
            return $result['material_data']['shikimori_rating'];
        else if ($this->getProperty($result['material_data'], 'mydramalist_rating'))
            return $result['material_data']['mydramalist_rating'];
        return 0;
    }
}
